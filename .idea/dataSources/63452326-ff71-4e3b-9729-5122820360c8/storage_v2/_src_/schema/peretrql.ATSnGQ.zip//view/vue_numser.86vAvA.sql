create view vue_numser as
select `peretrql`.`serveur`.`NOMSERV` AS `NOMSERV`
from `peretrql`.`serveur`;

